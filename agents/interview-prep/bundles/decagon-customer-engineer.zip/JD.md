# Customer Engineer, Agent Builder

**Company:** Decagon
**Location:** San Francisco
**Apply:** https://jobs.ashbyhq.com/decagon/8c40fb7a-5f25-4112-a1df-f1c22b81042c
**Ashby Org:** decagon
**Ashby Job ID:** 8c40fb7a-5f25-4112-a1df-f1c22b81042c

---

**About Decagon**

Decagon is the leading conversational AI platform empowering every brand to deliver concierge customer experiences.

Our technology enables industry-defining enterprises like Avis Budget Group, Block’s Cash App and Square, Chime, Oura Health, and Hunter Douglas to deploy AI agents that power personalized, deeply satisfying interactions across voice, chat, email, SMS, and every other channel.

We’re building a future where customer experiences are being redefined from support tickets and hold music to faster resolutions, richer conversations, and deeper relationships. We’re proud to be backed by world-class investors who share that vision, including a16z, Accel, Bain Capital Ventures, Coatue, and Index Ventures, along with many others.

We’re an in-office company, driven by a shared commitment to excellence and velocity. Our values — Just Get It Done, Invent What Customers Want, Winner’s Mindset, and The Polymath Principle — shape how we work and grow as a team.

**About the Team**

Over the past few years, development of LLMs has evolved at a rapid pace. It’s not enough for our customers to just “set it and forget it” when it comes to AI software. Truly successful AI Agents require hands-on execution, rigorous iteration, and deep technical delivery to reach enterprise-grade performance.

We’re creating an **Agent Builder Org**: a specialized technical delivery team responsible for end-to-end execution of AI agent builds. Agent Builders own the hands-on work required to deliver best-in-class agents—writing and configuring key components, validating integrations, and ensuring agents perform reliably at scale. This team brings greater specialization and focus to build quality. Agent Builders are technical and customer-facing: you’ll interface with senior technical stakeholders on the customer side while also going deep on agent configuration and build execution.

**About the Role**

As a **Customer Engineer, Agent Builder**, you will be responsible for end-to-end execution of AI agent builds for strategic customers. This is a highly technical delivery role where you will own the implementation work required to launch and scale enterprise-quality agents—partnering with customers and internal teams to define success, translate requirements into build plans, and deliver agents that meaningfully impact the customer’s business.

You’ll work closely with Agent PMs, Agent Success, Engineering, and GTM teams to create tight feedback loops: executing builds, surfacing gaps, and influencing the evolution of Decagon’s agent-building platform based on real customer needs. This role is ideal for someone who thrives in fast-moving environments, enjoys shipping customer-facing technical work, and can balance hands-on execution with structured thinking.

**In this role, you will**

- Own end-to-end execution of AI agent builds for enterprise customers, from initial scoping through launch and iteration.

- Write and maintain key agent-building artifacts (e.g., AOPs), and configure agent behavior to optimize quality, reliability, and business outcomes.

- Configure and validate guardrails to ensure safe, compliant, and predictable agent performance across real-world scenarios.

- Set up, test, and validate customer integrations (e.g., ticketing systems), including building tools and workflows needed for successful deployments.

- Interface with senior technical stakeholders at customers to define success criteria, gather requirements, and drive delivery against timelines.

- Translate customer needs into clear internal documentation and run tight feedback loops with Engineering to drive platform improvements.

- Partner closely with APMs, Engineering, Design, and Go-To-Market teams to deliver consistent, repeatable, best-in-class agent builds.

**Your background looks something like this**

- Have 5+ years of relevant experience in a technical customer-facing role (e.g., solutions engineering, forward-deployed engineering, technical consulting, implementation engineering, technical product/PM, or similar).

- Strong technical foundation: comfortable writing code, working with APIs, and building/validating integrations end-to-end.

Experience delivering production-grade customer solutions that require structured execution, testing/validation, and iteration.

- Ability to communicate clearly with senior technical stakeholders, translate requirements into implementation plans, and drive delivery.

- Comfort working in fast-moving, ambiguous environments where you shape solutions as much as you implement them.

**Even better if you have**

- Experience building with or around LLMs / AI agents (prompting, evaluation, guardrails, tooling, workflow design, etc.).

- Experience with enterprise SaaS integrations (e.g., ticketing systems, CRM, data pipelines) and associated security/compliance considerations.

- A Computer Science, Engineering, or Math degree, or equivalent technical experience.

- Strong product instinct: ability to write crisp PRDs, define success metrics, and contribute customer insight back into product roadmap.

**Compensation**

$175K – $230K • Offers Equity

**Benefits**

We proudly offer the following benefits for our full-time employees:

- Take what you need vacation policy (subject to local requirements; UK employees receive 25 days of statutory leave)

- Medical, Dental, and Vision benefits for you and your family

- Life Insurance and Disability Benefits

- Retirement Plan (e.g., 401K, pension)

- Parental Leave

- Fertility and family building benefits through Carrot

- Daily lunches and snacks in the office to keep you at your best

*These benefits are described in more detail in Decagon’s policies, may vary by location, and can change at any time according to applicable compensation and benefits plans.*
