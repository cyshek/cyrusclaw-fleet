# Technical Program Manager

**Company:** MediaAlpha
**Location:** Bellevue, Washington
**Apply:** https://job-boards.greenhouse.io/mediaalpha/jobs/8525774002
**Greenhouse ID:** 8525774002

---

MediaAlpha is a customer acquisition solutions provider powered by technology and data science. The company provides industry-leading solutions designed to reach consumers shopping within high-consideration categories such as property and casualty insurance, health insurance, life insurance, and more.

**Hybrid role: 2 days/week in office****

**

As a Technical Program Manager at MediaAlpha you'll sit at the nexus of engineering, business, and our external customers. You'll lead a functional area and work across teams to determine ongoing program needs, manage related projects, and define and measure success of your area.

The ideal candidate is someone that is detailed oriented, intensely curious and will foster, drive, and socialize a shared vision around their ownership area. You're comfortable reviewing code with engineers and talking business strategy with executive leadership. At MediaAlpha we're an intentionally small organization where individuals can have an outsized impact and opportunity, and we're looking for people that relentlessly look for ways to improve what we're doing, how we do it, and drive more value for our customers.

**Responsibilities**

- Oversee an end-to-end program, including defining metrics to measure success, monitor issues, and surface opportunities in systems that handle hundreds of thousands of high-value transactions per day.

- Work with external partners, internal account managers, and engineers to define, build, test, and release API integrations, related functionality, and supporting features.

- Manage Backlogs and Kanban workflows, and coordinate wider efforts across cross-functional teams.

- Consult with external partners on best practices for data passing and API design.

**Requirements**

- 3+ years of Program Management or related project experience, especially in an Agile environment and with the complete SDLC.

- Exceptional analytical skills.

- Experience with SQL, JSON, and Web APIs.

- Experience working with engineers and non-technical stakeholders.

- Ability to articulate and communicate clearly, concisely, and thoughtfully.

- A self-starter, comfortable with ambiguity and ability to problem-solve, while paying careful attention to detail.

- Knowledge of Atlassian Suite (JIRA, Confluence) a plus. 

 

Compensation & Benefits

We are excited to offer a competitive base pay range of $140,000 to $175,000 per year for this position, based on experience and qualifications. But that's not all - as a valued member of our team, you will also have access to an array of top-notch benefits, including:

- Annual bonus program and participation in our Restricted Stock Unit program

- 100% Employer-paid health, dental, and vision insurance for you, your dependents, and spouse or registered domestic partner

- 100% Employer paid long-term disability, and life insurance

- 401(k) retirement plan with matching contributions to help you plan for your future

- Open Paid Time Off policy with a birthday day off and 13 holidays 

- Professional development reimbursement 

- Cell Phone, Wellness, and Internet expense reimbursement, along with a subscription to the Calm App

- 100% fully paid parental leave for team members up to 22 weeks for the primary caregiver and 12 weeks for the secondary caregiver 

- Dog-friendly offices (LA and AZ) along with a $300 pet adoption reimbursement 

 

**Diversity, Equity, and Inclusion**

MediaAlpha is committed to fostering, cultivating, and maintaining a culture of diversity, equity, and inclusion. Our philosophy and actions are built on the premise that as an employer and citizens of our communities, we can create opportunities for lasting change. 

**Fair Chance**

MediaAlpha will consider qualified applicants, including those with criminal histories, in a manner consistent with state and local "Fair Chance" laws. We are also committed to providing reasonable accommodations for qualified applicants with disabilities and disabled veterans in our application process. If you need assistance or an accommodation due to a disability, please contact us at peopleops@mediaalpha.com or (213) 316-6256.
